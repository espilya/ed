
// NOMBRE Y APELLIDOS 

// COMENTARIO SOBRE LA SOLUCIÓN
// NO OLVIDES PONER EL COSTE JUSTIFICADO DE CADA OPERACIÓN JUNTO A ELLA

#ifndef ACADEMIACHINO
#define ACADEMIACHINO

#include <iostream>     
#include <string>
#include <stdexcept>
#include <algorithm>
using namespace std;

class academia_chino {
      
public:
   
};

#endif
